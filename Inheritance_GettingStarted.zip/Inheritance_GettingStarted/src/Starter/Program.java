package Starter;


import java.awt.Color;
import java.awt.Point;

public class Program {

	public static void main(String[] args) {

         
         
         


 		System.out.printf("\nShape Characteristics\n");
 		System.out.printf("----------------------\n");
 		//System.out.printf("Colour:        %s\n", blob.getColour());
 		//System.out.printf("Position:      %s\n", blob.getPosition());
 		
 		System.out.printf("\nCircle Characteristics\n");
 		System.out.printf("----------------------\n");
 		//System.out.printf("Colour:        %s\n", hoop.getColour());
 		//System.out.printf("Position:      %s\n", hoop.getPosition());
 		
 		System.out.println();

	}

}
