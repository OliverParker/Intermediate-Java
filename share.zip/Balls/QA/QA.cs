﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QA
{
    public class QA
    {
        public IDatabase IDatabase
        {
            get => default(QA.IDatabase);
            set
            {
            }
        }
    }
}