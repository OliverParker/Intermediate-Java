﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QA;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        World world1, world2;
        Painter painter;
        private void Form1_Load(object sender, EventArgs e)
        {
            World world0 = new World(ClientRectangle, new Point(), null, Color.Blue);

            world1 = new World(new Rectangle(30, 50, 200, 200), new Point(4,5), 
                world0, Color.Blue);
            world1.AddBall(1, 1, 10, 1, 1, world1, Color.Red);
            world1.AddBall(20, 10, 15, 2, 1, world1, Color.Yellow);
            world1.AddBall(30, 20, 8, 3, 2, world1, Color.Blue);

            world2 = new World(new Rectangle(130, 150, 50, 50), new Point(5, 4), 
                world1, Color.Green);
            world2.AddBall(1, 1, 5, 1, 1, world2 , Color.Red);
            world2.AddBall(20, 5, 5, 2, 1,world2, Color.Yellow);
            world2.AddBall(30, 4, 4, 3, 2, world2, Color.Blue);

            //world1.balls.Add(world2);

            timer1.Enabled = true;
            painter = new Painter(this.CreateGraphics());
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            world1.world.rectangle = this.ClientRectangle;
            world2.world.rectangle = this.ClientRectangle;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            painter.Cls();
            world1.Move();
            world2.Move();
            painter.Draw(world1);
            painter.Draw(world2); 
        }
    }
}
