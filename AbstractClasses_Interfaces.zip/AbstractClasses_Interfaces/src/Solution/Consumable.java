package Solution;

public interface Consumable {
	String describeTaste();

	String isMainCourseDish();
}
