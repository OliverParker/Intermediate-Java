package Solution;

public interface Insurable {
	String getPremium();

	String expires();
}
