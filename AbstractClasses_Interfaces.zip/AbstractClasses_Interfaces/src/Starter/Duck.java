package Starter;

public class Duck  {
	public Duck(String name) {
		
	}

}
