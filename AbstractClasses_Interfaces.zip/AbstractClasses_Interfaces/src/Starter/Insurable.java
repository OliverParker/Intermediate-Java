package Starter;

public interface Insurable {
	
	String getPremium();

	String expires();

}
