package Starter;

public class Penguin  {

	public Penguin(String name) {
		
	}

}
