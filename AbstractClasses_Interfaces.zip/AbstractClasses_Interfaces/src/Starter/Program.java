package Starter;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Object[] things = { 
				//new Penguin("Pingu") 
				//,new Duck("Donald")
				//,new Fish("Freddie") 
				          };

		System.out.println("### These are Consumable ###");

		// loop / test / downcast ref's and call

		System.out.println("\n### These are Insurable ###");

//		for (?? ? : ??) {
//			if (? ?? ??) {
//				?? ?? = (??) o;
//				System.out.printf("%s,\t%s\n", ii.??(), ii.??());
//			}
//		}
		System.out.println();
	}
}
