package Starter;

public interface Consumable {

}
