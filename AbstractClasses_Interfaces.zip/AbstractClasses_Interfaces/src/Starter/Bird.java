package Starter;

public class Bird  {

	private String name;

	public String getName() {
		return name;
	}

	public Bird(String name) {
		this.name = name;
	}


}
