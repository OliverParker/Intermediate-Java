package Solution.FactoryStuff;

public class NoMorePlatesException extends Exception {

}
