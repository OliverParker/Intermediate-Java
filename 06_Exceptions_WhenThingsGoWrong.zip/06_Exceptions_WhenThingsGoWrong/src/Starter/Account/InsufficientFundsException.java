package Starter.Account;

public class InsufficientFundsException 
                   //extends RuntimeException 
{

	public Account acc;
	public double amt;

//	public InsufficientFundsException(Account ac, double amount) {
//		?? = ??;
//		?? = ??;
//	}
}
