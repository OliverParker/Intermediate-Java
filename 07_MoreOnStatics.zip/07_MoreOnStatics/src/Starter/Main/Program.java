package Starter.Main;



public class Program {

	public static void main(String[] args) {
		// Display count
		System.out.printf("Vehicle Count = %d\n\n",0);
		
		// Create ArrayList of Vehicle
		
		// Loop to create 7 vehicles
		
		
		
		// Call accelerate or brake
		
		
		// Display details
		
		
		// Display count again
	}

}
