package Solution.Employees;

public class TechnicalAuthor extends SkilledWorker {

	public TechnicalAuthor(String name, String jobTitle) {
		super(name, jobTitle);
	}

}
