package Solution.Employees;

public class Draughtsman extends SkilledWorker {
	public Draughtsman(String name, String jobTitle) {
		super(name,jobTitle);
	}
}
