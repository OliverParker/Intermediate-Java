package Starter.Cars;

public class RacingCar extends Car {
    private String driver ;
    public String getDriver() {
		return driver;
	}
	private void setDriver(String driver) {
		this.driver = driver;
	}
	
	private int turboFactor ;
	public int getTurboFactor() {
		return turboFactor;
	}
	private void setTurboFactor(int turboFactor) {
		this.turboFactor = turboFactor;
	}
	
   
	public RacingCar(String model, String driver, int turboFactor)
    {
		//??
        setDriver(driver);
        setTurboFactor(turboFactor);
    }
	
}
