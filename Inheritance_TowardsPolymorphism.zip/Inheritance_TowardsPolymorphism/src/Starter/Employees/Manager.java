package Starter.Employees;



public class Manager // extends Employee 
{
	
}
