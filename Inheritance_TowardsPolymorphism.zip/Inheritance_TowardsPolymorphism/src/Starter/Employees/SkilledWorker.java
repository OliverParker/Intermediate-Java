package Starter.Employees;

public class SkilledWorker //extends Employee 
{


}
