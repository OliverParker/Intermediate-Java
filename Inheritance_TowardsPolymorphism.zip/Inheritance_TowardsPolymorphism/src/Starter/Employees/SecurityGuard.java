package Starter.Employees;

public class SecurityGuard // extends SkilledWorker 
{
	
}
