package Starter.Employees;

public class Draughtsman //extends SkilledWorker 
{

}
