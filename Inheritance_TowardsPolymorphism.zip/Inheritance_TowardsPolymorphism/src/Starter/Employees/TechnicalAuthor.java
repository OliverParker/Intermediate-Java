package Starter.Employees;

public class TechnicalAuthor //extends SkilledWorker 
{


}
